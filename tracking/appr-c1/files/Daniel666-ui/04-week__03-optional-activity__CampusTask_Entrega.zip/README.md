# CampusTask – Academic Task Manager

## Project pitch

CampusTask is a mobile application designed to help university students organize their academic responsibilities in one place. Many students have difficulties keeping track of assignments, exams, deadlines, and their progress across different courses. The target users are university and technical students who need a simple and fast way to manage their academic workload. The MVP allows users to create academic tasks with deadlines, organize them by subject and priority, and mark tasks as completed while tracking their progress. The goal is to reduce missed deadlines and improve students' time management without adding unnecessary complexity. In future versions, the application could include notifications, cloud synchronization, and collaborative study features.

## Problema

Los estudiantes universitarios suelen manejar tareas, parciales, proyectos y fechas de entrega en diferentes plataformas, chats o apuntes. Esto puede provocar olvidos, entregas tardías y dificultad para identificar qué actividad debe atenderse primero.

## Público objetivo

Estudiantes universitarios y de formación técnica o tecnológica que necesiten organizar de manera sencilla sus actividades académicas, especialmente quienes cursan varias asignaturas al mismo tiempo.

## MVP – 3 funciones imprescindibles

1. Crear tareas académicas indicando título, asignatura, fecha límite y prioridad.
2. Visualizar y organizar las tareas por asignatura, prioridad y estado.
3. Marcar tareas como completadas y consultar el progreso general.

## Historias de usuario y criterios de aceptación

### HU1 – Crear una tarea
**Como** estudiante, **quiero** registrar una tarea académica **para** recordar qué debo entregar.

**Criterios de aceptación:**
- El sistema permite ingresar título, asignatura y fecha límite.
- El título es obligatorio.
- Al guardar, la tarea aparece en la lista de pendientes.

### HU2 – Asignar prioridad
**Como** estudiante, **quiero** asignar una prioridad a cada tarea **para** identificar qué actividades debo realizar primero.

**Criterios de aceptación:**
- Se puede seleccionar prioridad alta, media o baja.
- La prioridad queda visible en la lista de tareas.
- Si no se selecciona una prioridad, se asigna “media” por defecto.

### HU3 – Organizar por asignatura
**Como** estudiante, **quiero** clasificar mis tareas por asignatura **para** consultar rápidamente las actividades de cada materia.

**Criterios de aceptación:**
- Cada tarea puede asociarse a una asignatura.
- El usuario puede filtrar la lista por asignatura.
- Al quitar el filtro se muestran nuevamente todas las tareas.

### HU4 – Marcar una tarea como completada
**Como** estudiante, **quiero** marcar una tarea como completada **para** distinguirla de las actividades pendientes.

**Criterios de aceptación:**
- Cada tarea pendiente tiene una opción para marcarla como completada.
- La tarea cambia de estado inmediatamente.
- Una tarea completada no aparece como pendiente.

### HU5 – Consultar progreso
**Como** estudiante, **quiero** ver mi progreso académico **para** saber cuántas tareas he completado y cuántas tengo pendientes.

**Criterios de aceptación:**
- Se muestra el total de tareas.
- Se muestra el número de tareas completadas y pendientes.
- El progreso se actualiza al cambiar el estado de una tarea.

### HU6 – Ordenar por fecha límite
**Como** estudiante, **quiero** ordenar mis tareas por fecha de entrega **para** atender primero las que vencen más pronto.

**Criterios de aceptación:**
- Existe una opción para ordenar por fecha límite.
- Las tareas con fecha más cercana aparecen primero.
- Las tareas sin fecha, si existieran, aparecen al final.

## Backlog priorizado – 3 sprints

| Prioridad | Historia | Sprint | Resultado esperado |
|---|---|---|---|
| 1 | HU1 – Crear una tarea | Sprint 1 | Registro básico de actividades |
| 2 | HU4 – Marcar como completada | Sprint 1 | Gestión del estado de las tareas |
| 3 | HU2 – Asignar prioridad | Sprint 1 | Identificación de tareas importantes |
| 4 | HU3 – Organizar por asignatura | Sprint 2 | Clasificación y filtrado |
| 5 | HU6 – Ordenar por fecha límite | Sprint 2 | Organización por vencimiento |
| 6 | HU5 – Consultar progreso | Sprint 3 | Resumen del avance académico |

### Sprint 1 – Núcleo funcional
HU1, HU4 y HU2. Al terminar este sprint el usuario puede crear tareas, establecer su prioridad y marcarlas como completadas.

### Sprint 2 – Organización
HU3 y HU6. Se incorporan filtros por asignatura y ordenamiento por fecha límite.

### Sprint 3 – Seguimiento
HU5. Se añade un resumen de progreso con tareas totales, pendientes y completadas. El sprint también se utiliza para pruebas y ajustes finales del MVP.

## Tipo de aplicación

Se propone una **aplicación móvil**. El público objetivo consulta constantemente el teléfono durante su jornada académica y necesita registrar o revisar tareas desde cualquier lugar. Una interfaz móvil permite acceso rápido, portabilidad y una experiencia enfocada en acciones breves como crear, consultar y completar actividades.

## Metodología

Se utilizará **Scrum**, adaptado a un proyecto académico pequeño. La metodología permite dividir el desarrollo en incrementos cortos, priorizar un backlog y obtener una versión funcional al finalizar cada sprint. Los tres sprints facilitan desarrollar primero las funciones esenciales del MVP, después mejorar la organización y finalmente incorporar el seguimiento del progreso y las pruebas.
